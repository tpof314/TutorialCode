package simulation;

import core.Cell;

/**
 * 这个类代表了变异细胞. 变异细胞也是活细胞的一种,
 * 但是它们的迭代方式和正常细胞有所不同.
 * 变异细胞没有体力值(stamina).
 */
public class MutatedCell extends Cell
{
	@Override
	public Cell getNextStage(int numNormalNeighbours, int numMutatedNeighbours)
	{
		
	}
}
