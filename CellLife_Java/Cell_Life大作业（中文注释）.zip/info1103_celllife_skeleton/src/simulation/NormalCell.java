package simulation;

import core.Cell;

/**
 * NormalCell代表正常、健康的细胞. 
 * 一个正常细胞会带有一个体力值(stamina). 
 * 所有正常细胞在新生的时候, 体力值会恢复到100%.
 * 如果体力值掉到1%或者1%以下, 细胞就会死掉.
 */
public class NormalCell extends Cell
{	
	
	/**
	 * 返回细胞的体力值.
	 * 
	 * 0.0 表示 0%, 1.0 表示 100%.
	 * 
	 * @return 返回细胞的体力值.
	 */
	public double getPercentStamina() {
		
	}
	
	@Override
	public Cell getNextStage(int numNormalNeighbours, int numMutatedNeighbours)
	{
		
	}
}
