package simulation;

import core.Cell;

/**
 * 这个类代表了死细胞.
 * 死细胞没有体力值(stamina).
 */
public class DeadCell extends Cell
{
	@Override
	public Cell getNextStage(int numNormalNeighbours, int numMutatedNeighbours)
	{
		
	}
}
