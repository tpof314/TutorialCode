package simulation;

import core.Cell;

public class CellGrid
{
	// 将模拟实验中的细胞保存在这个二维数组里面
	private Cell[][] cells;

	/**
	 * CellGrid的构造方法. 
	 * 初始化cells数组, 生成一堆的细胞(可能是活细胞, 也可能是死细胞).
	 * 具体细胞的死活根据lifeChance所给的存活概率而定.
	 * 一开始的活细胞中，没有变异细胞.
	 * 
	 * @param size
	 *            二维数组的大小是 size x size
	 * @param lifeChance
	 *            每一个细胞一开始存活的概率
	 * @param mutationChance
	 *            细胞迭代过程中发生变异的概率
	 */
	public CellGrid(int size, double lifeChance, double mutationChance)
	{
		
	}

	/**
	 * 执行一步细胞迭代的模拟实验. 一共分为两步走:
	 * 
	 * 1. 按照作业中提及的要求，根据每个细胞的邻居细胞数量，更新二维数组
	 *    里面的所有细胞.
	 * 2. 按照变异概率, 对所有的活细胞都进行一次变异尝试
	 */
	public void simulateStep()
	{
		
	}
	
	/**
	 * 对所给坐标中的细胞进行一次变异尝试. 
	 * 做变异尝试的时候, 需要根据构造方法中所给的变异概率进行尝试.
	 * 只有活着的正常细胞才能发生变异.
	 * 
	 * 注意: 这个方法可能直接导致(x, y)上的细胞直接从NormalCell变成
	 *       MutatedCell，不仅仅是返回一个boolean结果.
	 * 
	 * @param x
	 *            x 坐标
	 * @param y
	 *            y 坐标
	 * @return 如果编译成功的话返回true, 变异失败返回false.  (x,y)如果
	 *         出界的话，也算变异失败.
	 */
	public boolean mutateCell(int x, int y)
	{
		
	}
	
	/**
	 * 判断坐标(x, y)是不是在网格内.
	 * 
	 * @param x
	 *            x 坐标
	 * @param y
	 *            y 坐标
	 * @return 如果(x, y)在网格范围内, 返回true. 否则返回false.
	 */
	public boolean isValidCoordinate(int x, int y)
	{
		
	}
	
	/**
	 * 统计以(x, y)为中心的8个邻居细胞中，有多少个正常细胞.
	 * 
	 * @param x
	 *            x 坐标
	 * @param y
	 *            y 坐标
	 * @return 返回正常细胞的数量. 如果(x, y)出界, 返回0.
	 */
	public int countNormalNeighbours(int x, int y)
	{
		
	}
	
	/**
	 * 统计以(x, y)为中心的8个邻居细胞中，有多少个变异细胞.
	 * 
	 * @param x
	 *            x 坐标
	 * @param y
	 *            y 坐标
	 * @return 返回变异细胞的数量. 如果(x, y)出界, 返回0.
	 */
	public int countMutatedNeighbours(int x, int y)
	{
		
	}
	
	/**
	 * 返回坐标为(x, y)上面的细胞.
	 * 
	 * @param x
	 *            x 坐标
	 * @param y
	 *            y 坐标
	 * @return 返回坐标为(x, y)上面的细胞, 如果(x, y)出界, 返回null.
	 */
	public Cell getCell(int x, int y)
	{
		
	}

	/**
	 * 把坐标为(x, y)上面的细胞改成cell.
	 * 
	 * @param x
	 *            需要被修改细胞的 x 坐标
	 * @param y
	 *            需要被修改细胞的 y 坐标
	 * @param cell
	 *            要改成的那个细胞.
	 */
	public void setCell(int x, int y, Cell cell)
	{
		
	}

	/**
	 * 判断是不是有“变异爆发”发生. “变异爆发”发生在: 当变异细胞的数量占
	 * 活着细胞的数量的10%或10%以上的时候.
	 * 
	 * 注意: 活着的细胞包括了“正常细胞”和“变异细胞”.
	 * 
	 * @return 如果“变异爆发”返回true, 否则返回false.
	 */
	public boolean isOutbreakOccurring() 
	{
		
	}
	
	/**
	 * 判断坐标为(x, y)上面的细胞是不是正常细胞(或者并且没变异).
	 * 
	 * @param x
	 *            细胞的 x 坐标
	 * @param y
	 *            细胞的 y 坐标
	 * @return 如果(x, y)上的细胞是正常细胞, 返回true. 否则返回false.
	 */
	public boolean isNormalCell(int x, int y)
	{
		// 这个方法已经帮你写好了, 请不要做任何修改!
		return (getCell(x, y) instanceof NormalCell);
	}

	/**
	 * 判断坐标为(x, y)上面的细胞是不是变异细胞.
	 * 
	 * @param x
	 *            细胞的 x 坐标
	 * @param y
	 *            细胞的 y 坐标
	 * @return 如果(x, y)上的细胞是变异细胞, 返回true. 否则返回false.
	 */
	public boolean isMutatedCell(int x, int y)
	{
		// 这个方法已经帮你写好了, 请不要做任何修改!
		return (getCell(x, y) instanceof MutatedCell);
	}
}
